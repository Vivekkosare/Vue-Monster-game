
<template>

  <div id="app">
    <div class="container">
      <div class="row statusblock">
        <div class="col-md-6">
          <div class="text-center" style="width:100%;">
            <h1>You</h1>
            <div style="border:thin;background-color:lightgrey;">
            <div class="healthbar" :style="{width:playerHealth+'%'}">{{playerHealth}}</div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="text-center" style="width:100%;">
            <h1>Monster</h1>
            <div style="border:thin;background-color:lightgrey;">
              <div class="healthbar" :style="{width:monsterHealth+'%'}">{{monsterHealth}}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="row" style="padding-bottom:25px;" v-if="!gameIsRunning">
            <div class="buttonblock">
              <button class="btn btn-success" @click="startGame" style="width: 250px;font-size:16pt;">Start New Game</button>
            </div>
      </div>
      <div class="row" v-else>
            <div class="buttonblock">
              <button class="btn btn-danger buttonact" @click="attack">Attack</button>
              <button class="btn btn-primary buttonact" @click="specialAttack">Special Attack</button>
              <button class="btn btn-info buttonact" @click="heal">Heal</button>
              <button class="btn btn-warning buttonact" @click="giveUp">Give Up</button>
            </div>
      </div>
      <div style="padding-top:25px;" v-if="turns.length>0">
              <div v-for="turn in turns" v-bind:key="turn"
              :class="{'player-turn':turn.isPlayer, 'monster-turn':!turn.isPlayer}">
              {{turn.text}}
              </div>
      </div>
    </div>
  </div>
</template>
<script src="https://cdn.jsdelivr.net/npm/vue"></script>
<script>
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      playerHealth:100,
      monsterHealth:100,
      gameIsRunning: false,
      turns: []
    }

  },
  methods:{
    startGame:function(){
      this.gameIsRunning=true;
      this.playerHealth=100;
      this.monsterHealth=100;
      this.turns=[];
    },
    attack: function(){
      var damage = this.calculateDamage(3,10);
      this.monsterHealth -= damage;
      this.turns.unshift({
        isPlayer: true,
        text: 'Player hits Monster for: ' + damage
        });
      if(this.checkWin())
      {
        //returns true because the further code should not be executed any more..
        return;
      }
      this.monsterAttacks();
    },

    giveUp: function(){
      this.gameIsRunning=false;
    },

    heal: function(){
      console.log('called heal');
      if(this.playerHealth<=90)
      {
        this.playerHealth += 10;
      }
      else{
        this.playerHealth = 100;
      }
      this.turns.unshift({
        isPlayer: true,
        text: 'Player heals for 10'
        });
      this.monsterAttacks();

    },

    calculateDamage: function(min, max){
      return Math.max(Math.floor(Math.random()*max)+1,min);
    },

    checkWin: function(){
      if(this.monsterHealth<=0)
      {
        if(confirm('You won!! New Game?'))
        {
          this.startGame();
        }
        else{
          this.gameIsRunning=false;
        }
        return true;
      }
      else if(this.playerHealth<=0)
      {
        if(confirm('You lost!! New Game?'))
        {
          this.startGame();
        }
        else{
          this.gameIsRunning=false;
        }
        return true;
      }

      return false;
    },
    monsterAttacks: function(){
      var damage = this.calculateDamage(5,12);
      this.playerHealth -= damage;
      this.turns.unshift({
        isPlayer: false,
        text: 'Monster hits Player for: ' + damage
        });
      //this function does not return true or false because there is no more code to be executed.
      this.checkWin();

    },
    specialAttack: function(){
      console.log('called special attack');
      var damage = this.calculateDamage(10,20);
      this.monsterHealth -= damage;

      this.turns.unshift({
        isPlayer: true,
        text: 'Player hits hard Monster for: ' + damage
        });
      if(this.checkWin())
      {
        //returns true because the further code should not be executed any more..
        return;
      }
      this.monsterAttacks();
    }

  }
}
</script>


<style lang="scss">

</style>
